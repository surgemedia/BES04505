<footer id="footer">
  <div class="container">
     <?php echo date("Y"); ?> &copy; BESPOKE MONEY
  </div>
</footer>